var bio = {
	"name" : "Sourabh Maheshwari",
	"role" : "Software Engineer / Web Developer",
	"contacts" : {
		"mobile" : "+91 7568245457",
		"email" : "saurabhm@iitj.ac.in",
		"github" : "sousnake",
		"location" : "Bangaluru, India"	
	},
	"welcomeMessage" : "Hi everyone, I am Software Engineer with about 2 years of experience in field of Software Development. "+
						"Fascinated by web technologes, my current endeavor is to build dynamic and responsive websites to add to my "+
						"portfolio. I'm very passionate about programming and curious to know more about newer technologies."+
						"<br> My hobbies are playing computer games (CS 1.6, CS GO), listening music and doing card tricks.",
	"skills" : ["JAVA/J2EE", "C++", "Spring Framework", "Hibernate", "Mybatis", "HTML/CSS/JS", "AngularJS", "PHP", "DB2/SYBASE/MongoDB", "Android" ],
	"image" : "images/me.jpg"
};

var work = {
 	"jobs" : [
 		{
			"title" : "Senior Analyst",
			"employer" : "Morgan Stanley Advantages Services",
			"dates" : "August 2014 - Present",
			"location" : "Bangaluru",
			"description" : "Working as Java Developer on Distributed Side in Gain & Loss in Core Processing.<br>"+
				"Abstaction Layer : To reduce dependence on mainframe as part of the strategic initiatives at Morgan Stanley, Abstraction Layer is built. This is a distributed application whose processing power and speed would match that of the Mainframe. In the long run, this application would facilitate the move away from Mainframe based Tax Computation Engine to a distributed Gain-Loss system."+
				"<br>Recon Tool: Developed a reconciliation application which does a differential analysis using tokens. Java, JavaScript, AJAX, iBatis"+
				"were the technologies used. This tool was needed to reconciliate files from different sources and fix the breaks automatically.<br>"+
				"ProductSyncer: Redeveloped an existing ProductSyncer application to improve performance for handling bulk product request. It "+
				"was also configured to support sophisticated configurations for product update from different external source.",
			"url" : "http://www.morganstanley.com/about-us/global-offices/india"
		},
		{
			"title" : "Internship",
			"employer" : "Tata Consultancy Services",
			"dates" : "May 2013 - July-2013",
			"location" : "Bangaluru",
			"description" : "Implementing the Finite Automaton in Java. Is basically builds NFA from a given regular expressions and then constructs DFA from it."+
				"Applied the algorithms for converting FA to CFG, minimizing FA, NFA to DFA, combingin DFA and many others studied in Theory of Computation in a much practical manner on a working model.<br> Also implemented attribute "+ 
				"based encryption scheme in Java, building public key generators and access tree structures. This part was related"+ 
				"to number theory of random numbers and prime numbers. In ABE basically identity is not atomic but as a set of attributes, "+
				"e.g., roles, and messages encrypted with respect to subsets of attributes (key-policy ABE - KP-ABE) or policies defined over "+
				"a set of attributes (ciphertext-policy ABE - CP-ABE). The key is, that someone should only be able to decrypt a ciphertext if "+
				"the person holds a key for matching attributes (more below) where user keys are always issued by some trusted party.",
			"url" : "http://www.tcs.com/Pages/default.aspx"	
		}
	]
};


var education  = {

	"schools" : [
		{
			"name" : "INDIAN INSTITUTE OF TECHNOLOGY JODHPUR",
			"location" :"Jodhpur",
			"degree" : "B. Tech",
			"majors" : ["Computer Science"],
			"dates" : "2010 - 2014",
			"url" : "http://www.iitj.ac.in/"
		},
		{
			"name" : "MAHESHWARI PUBLIC SCHOOL",
			"location" :"Jaipur",
			"degree" : "High School",
			"majors" : ["P.C.M."],
			"dates" : "2008 - 2010",
			"url" : "http://www.mpsjaipur.com/"
		}
	 ],
	"onlineCourses" : [
		{
			"title": "Developing Android Apps",
			"school" : "Udacity",
			"dates" : "Aug -2015",
			"url" : "https://www.udacity.com/course/developing-android-apps--ud853"
		},
		{
			"title": "Developing Scalable Apps in Java",
			"school" : "Udacity",
			"dates" : "Feb - 2016",
			"url" : "https://www.udacity.com/course/developing-scalable-apps-in-java--ud859"
		},
		{
			"title": "Algorithms Part 1",
			"school" : "Coursera",
			"dates" : "May - 2015",
			"url" : "https://www.coursera.org/course/algs4partI"
		},
		{
			"title": "Algorithms Part 2",
			"school" : "Coursera",
			"dates" : "Nov - 2015",
			"url" : "https://www.coursera.org/course/algs4partII"
		}
		,
		{
			"title": "Web Development",
			"school" : "Udacity",
			"dates" : "Dec - 2015",
			"url" : "https://www.udacity.com/course/web-development--cs253"
		}		
	]
};

var projects = {
	"projects" : [
		{
			"title" : "Resume Uploading Portal",
			"dates" : "March - 2013",
			"description" : "This project is a SPC portal managing student resume. Students can register on site and upload their resume as "+
					"excel file with format specified on webpage or can fill it via form. Students can update their resume anytime as "+
					"well as upload their image. It uses phpexcel to retreive information from excel and update excel as well. Site maintains student "+
					"files in a dynamic folder created at time of uploading. JavaScript used for validation and CSS used for styles and php for backend."+
						" Also admin can login and can view students resume.",
			"url" : "https://github.com/sousnake/resume-uploading-portal",			
			"images" :  ["images/home.png","images/viewresume.png"]
		},
		{
			"title" : "Cab Booking Service",
			"dates" : "October - 2014",
			"description" : "The cab booking service is a service providing application which help user book available cabs.The cab provider "+ 
					"register his cars and maintain their details whereas users can also maintain their account and all services. The details"+ 
					"are maintained in database implemented by SQL. Also new car registration and new user registration can be done, "+
					"the current can be reset to nil. It also calculate the optimum path for reaching the destination and tell custmor "+
					"that the car is availible or not, and if it is availible how much time it will take and cost of serice." ,
			"url" : "https://github.com/sousnake/cab-booking-service",		
			"images" :  ["images/carregistration.png","images/city.png"]
		}
	]
};

$(document).click(function(loc) { 
	logClicks(loc.pageX,loc.pageY);
});
function inName(oldName) {
    var  array = oldName.split(" ");
	console.log(array);
	var first = array[0];
    first = first.slice(0,1).toUpperCase()+ first.slice(1).toLowerCase();
    return first + " "+array[1].toUpperCase();
};

$("#main").append(internationalizeButton);